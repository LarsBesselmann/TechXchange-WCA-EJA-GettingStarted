package com.acme.modres.security;

// import com.sun.net.ssl.TrustManager;

// public class FakeX509TrustManager implements TrustManager {
public class FakeX509TrustManager {

}
